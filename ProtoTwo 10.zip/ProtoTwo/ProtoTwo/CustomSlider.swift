//
//  CustomSlider.swift
//  ProtoTwo
//
//  Created by Don on 2016-09-30.
//  Copyright © 2016 Don. All rights reserved.
//

import UIKit

class CustomSlider: UIControl {

   
    
}
