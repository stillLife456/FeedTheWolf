//
//  TotalsCell.swift
//  ProtoTwo
//
//  Created by Don on 2016-10-23.
//  Copyright © 2016 Don. All rights reserved.
//

import Foundation
import UIKit

class TotalsCell: UITableViewCell {



    @IBOutlet weak var totalDescriptionLabel: UILabel!

    @IBOutlet weak var totalRatingLabel: UILabel!










}