//
//  TimeTableViewCell.swift
//  ProtoTwo
//
//  Created by 田中早紀 on 2016-08-15.
//  Copyright © 2016 Don. All rights reserved.
//

import Foundation
import UIKit

class TimeTableViewCell:UITableViewCell {
    
    @IBOutlet var titleLable: UILabel!
    @IBOutlet weak var weekdayLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
}