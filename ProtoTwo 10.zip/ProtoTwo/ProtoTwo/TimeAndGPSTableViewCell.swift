//
//  TimeAndGPSTableViewCell.swift
//  ProtoTwo
//
//  Created by 田中早紀 on 2016-08-15.
//  Copyright © 2016 Don. All rights reserved.
//

import Foundation
import UIKit

class TimeAndGPSTableViewCell:UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var weekdayLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var mapButton: UIButton!
    
    @IBAction func pressedButton(sender: AnyObject) {
    }
    
}
